﻿#include <bits/stdc++.h>
using namespace std;
const int N = 1e3 + 10;
// m数组表示乘法最小数
int n, p[N + 1], m[N + 1][N + 1];

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        scanf("%d %d", &p[i - 1], &p[i]);  // p储存矩阵行列数

    for (int i = 1; i <= n; i++)
        m[i][i] = 0;

    for (int l = 2; l <= n; l++) {
        for (int i = 1; i <= n - l + 1; i++) {
            int j = i + l - 1;
            m[i][j] = 9999999;
            for (int k = i; k <= j - 1; k++) {
                m[i][j] = min(m[i][j],
                              m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j]);
            }
        }
    }
    printf("%d\n", m[1][n]);
    return 0;
}
